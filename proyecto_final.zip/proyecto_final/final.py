import tkinter as tk
import random
import time
import threading
from collections import deque
import math

# ==========================================
# CONFIGURACIÓN Y CONSTANTES
# ==========================================
COLOR_BG = "#050505"
COLOR_WALL = "#222222"
COLOR_PATH = "#111111"
COLOR_PLAYER = "#00ff00"
COLOR_BOSS = "#ff3333"
COLOR_RIVAL = "#aa00ff"
COLOR_GOAL = "#ffd700"
COLOR_TRAP = "#660000"
COLOR_CHEST = "#0088ff"
COLOR_BTN = "#333333"
COLOR_BTN_TXT = "#ffffff"

ANCHO_VENTANA = 900
ALTO_VENTANA = 700

# ==========================================
# SONIDO
# ==========================================
class SoundManager:
    @staticmethod
    def play(freq, dur):
        def _beep():
            try:
                import winsound
                winsound.Beep(freq, dur)
            except ImportError:
                pass
        threading.Thread(target=_beep, daemon=True).start()

# ==========================================
# PATHFINDING
# ==========================================
class Pathfinder:
    @staticmethod
    def bfs(start, goal, grid, cols, rows):
        queue = deque([[start]])
        visited = {start}
        dirs = [(0,-1),(0,1),(-1,0),(1,0)]
        while queue:
            path = queue.popleft()
            x, y = path[-1]
            if (x,y) == goal:
                return path
            for dx, dy in dirs:
                nx, ny = x+dx, y+dy
                if 0 <= nx < cols and 0 <= ny < rows:
                    if grid[ny][nx] == 0 and (nx,ny) not in visited:
                        visited.add((nx,ny))
                        queue.append(path + [(nx,ny)])
        return [start]

# ==========================================
# GENERADOR DE LABERINTO
# ==========================================
class MazeGenerator:
    @staticmethod
    def generate(cols, rows):
        if cols % 2 == 0: cols += 1
        if rows % 2 == 0: rows += 1
        maze = [[1 for _ in range(cols)] for _ in range(rows)]
        stack = [(1,1)]
        maze[1][1] = 0
        while stack:
            x, y = stack[-1]
            neighbors = []
            for dx, dy in [(0,-2),(0,2),(-2,0),(2,0)]:
                nx, ny = x+dx, y+dy
                if 1 <= nx < cols-1 and 1 <= ny < rows-1 and maze[ny][nx] == 1:
                    neighbors.append((nx,ny))
            if neighbors:
                nx, ny = random.choice(neighbors)
                maze[(y+ny)//2][(x+nx)//2] = 0
                maze[ny][nx] = 0
                stack.append((nx,ny))
            else:
                stack.pop()
        maze[rows-2][cols-2] = 0
        return maze, cols, rows

# ==========================================
# MOTOR DEL JUEGO
# ==========================================
class GameEngine:
    def __init__(self, root, mode, on_exit_callback):
        self.root = root
        self.mode = mode
        self.on_exit = on_exit_callback
        
        self.level = 1
        self.base_cols = 15
        self.base_rows = 11
        
        self.is_running = False
        self.game_over = False
        
        self.canvas = tk.Canvas(root, bg=COLOR_BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        
        self.keys = set()
        self.root.bind("<KeyPress>", self._on_press)
        self.root.bind("<KeyRelease>", self._on_release)

        self.btn_exit = None  
        self.start_level()

    def _on_press(self, event):
        self.keys.add(event.keysym.lower())

    def _on_release(self, event):
        key = event.keysym.lower()
        if key in self.keys:
            self.keys.remove(key)

    def crear_boton_salida(self):
        if self.btn_exit:
            self.btn_exit.lift()
            return
        self.btn_exit = tk.Button(
            self.root, text="🏠 MENÚ",
            font=("Arial",10,"bold"),
            bg="#880000", fg="white",
            activebackground="#aa0000",
            command=self.exit_to_menu
        )
        self.btn_exit.place(relx=0.98, rely=0.98, anchor="se")

    def start_level(self):
        incremento = (self.level - 1) * 4
        self.cols = self.base_cols + incremento
        self.rows = self.base_rows + incremento
        
        self.maze, self.cols, self.rows = MazeGenerator.generate(self.cols, self.rows)
        
        self.player_pos = [1,1]
        self.goal_pos = (self.cols-2, self.rows-2)
        
        self.max_hp = 20 + (self.level * 5)
        self.hp = self.max_hp
        self.last_move_time = time.time()
        
        self.traps = []
        self.chests = []
        
        valid = []
        for y in range(self.rows):
            for x in range(self.cols):
                if self.maze[y][x] == 0 and (x,y) not in [(1,1), self.goal_pos]:
                    valid.append((x,y))
        random.shuffle(valid)
        
        for _ in range(min(5 + self.level*2, len(valid))):
            self.traps.append(valid.pop())
        for _ in range(min(3 + self.level//2, len(valid))):
            self.chests.append(valid.pop())

        self.boss_pos = None
        self.boss_timer = 0
        self.rival_pos = None
        self.rival_path = []
        self.rival_index = 0
        self.rival_timer = 0
        
        if self.mode == "jefe":
            self.boss_pos = [self.cols//2, self.rows//2]
            self.maze[self.boss_pos[1]][self.boss_pos[0]] = 0
        elif self.mode == "carrera":
            self.rival_pos = [1,1]
            self.rival_path = Pathfinder.bfs((1,1), self.goal_pos, self.maze, self.cols, self.rows)
            if len(self.rival_path) < 2:
                self.rival_path = [(1,1)]

        self.is_running = True
        self.game_over = False
        self.crear_boton_salida()
        self.loop()

    def update_physics(self):
        if self.game_over: return
        
        curr = time.time()
        if curr - self.last_move_time > 0.08:
            dx = dy = 0
            if "w" in self.keys or "up" in self.keys: dy = -1
            elif "s" in self.keys or "down" in self.keys: dy = 1
            elif "a" in self.keys or "left" in self.keys: dx = -1
            elif "d" in self.keys or "right" in self.keys: dx = 1
            
            if dx or dy:
                nx = self.player_pos[0] + dx
                ny = self.player_pos[1] + dy
                if 0 <= nx < self.cols and 0 <= ny < self.rows:
                    if self.maze[ny][nx] == 0:
                        self.player_pos = [nx, ny]
                        self.check_collisions()
                        self.last_move_time = curr

        if self.mode == "jefe" and self.boss_pos:
            self.boss_timer += 1
            speed = 20 if self.level == 1 else 15
            if self.boss_timer > speed:
                self.boss_timer = 0
                path = Pathfinder.bfs(tuple(self.boss_pos), tuple(self.player_pos), self.maze, self.cols, self.rows)
                if len(path) > 1:
                    self.boss_pos = list(path[1])
                if self.boss_pos == self.player_pos:
                    self.take_damage(2)

        if self.mode == "carrera" and self.rival_path:
            self.rival_timer += 1
            if self.rival_timer > 15:
                self.rival_timer = 0
                if self.rival_index < len(self.rival_path)-1:
                    self.rival_index += 1
                    self.rival_pos = list(self.rival_path[self.rival_index])
                if tuple(self.rival_pos) == self.goal_pos:
                    self.end_game(False, "¡El fantasma ganó!")

    def check_collisions(self):
        pos = tuple(self.player_pos)
        if pos == self.goal_pos:
            SoundManager.play(1000,200)
            self.end_game(True)
            return
        if pos in self.traps:
            self.take_damage(3)
            self.traps.remove(pos)
        if pos in self.chests:
            self.hp = min(self.max_hp, self.hp+5)
            self.chests.remove(pos)
            SoundManager.play(600,150)

    def take_damage(self, amount):
        self.hp -= amount
        SoundManager.play(150,200)
        if self.hp <= 0:
            self.end_game(False, "Te has quedado sin vida")

    def draw(self):
        self.canvas.delete("all")
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        size = min(w/self.cols, h/self.rows)
        ox = (w - size*self.cols)/2
        oy = (h - size*self.rows)/2

        def rect(x,y,color,scale=1):
            m = (1-scale)*size/2
            x1 = ox + x*size + m
            y1 = oy + y*size + m
            self.canvas.create_rectangle(
                x1, y1, x1+size*scale, y1+size*scale,
                fill=color, outline=""
            )

        for y in range(self.rows):
            for x in range(self.cols):
                rect(x,y, COLOR_WALL if self.maze[y][x] else COLOR_PATH)
        rect(*self.goal_pos, COLOR_GOAL)
        for t in self.traps: rect(*t,COLOR_TRAP,0.6)
        for c in self.chests: rect(*c,COLOR_CHEST,0.7)
        if self.rival_pos: rect(*self.rival_pos,COLOR_RIVAL,0.8)
        if self.boss_pos: rect(*self.boss_pos,COLOR_BOSS,0.9)
        rect(*self.player_pos,COLOR_PLAYER,0.8)

        bar_w = 200
        fill = int((self.hp/self.max_hp)*bar_w)
        hp_color = "#00ff00" if self.hp > self.max_hp*0.5 else "#ff0000"
        self.canvas.create_rectangle(20,20,220,40,outline="white",fill="#333")
        self.canvas.create_rectangle(20,20,20+fill,40,outline="",fill=hp_color)
        self.canvas.create_text(25,30,text=f"{self.hp}/{self.max_hp} HP",fill="white",anchor="w")

        self.canvas.create_text(w-20,30,text=f"NIVEL: {self.level}",anchor="ne",fill="white",font=("Arial",16,"bold"))
        self.canvas.create_text(w//2,30,text=self.mode.upper(),fill="#888",font=("Arial",12))

    def end_game(self, victory, razon=""):
        self.game_over = True
        if self.btn_exit:
            self.btn_exit.destroy()
            self.btn_exit = None

        self.canvas.delete("all")
        bg = "#004400" if victory else "#440000"
        self.canvas.configure(bg=bg)
        
        msg = "¡VICTORIA!" if victory else "DERROTA"
        cw, ch = self.root.winfo_width(), self.root.winfo_height()
        self.canvas.create_text(cw//2, ch//2 - 50, text=msg, fill="white", font=("Impact", 40))
        self.canvas.create_text(cw//2, ch//2 + 20, text=razon, fill="#ccc", font=("Arial", 16))

        if victory:
            self.root.after(2000, self.next_level)
        else:
            self.root.after(3000, self.exit_to_menu)

    def next_level(self):
        self.level += 1
        self.canvas.configure(bg=COLOR_BG)
        self.start_level()

    def exit_to_menu(self):
        self.is_running = False
        if self.btn_exit:
            self.btn_exit.destroy()
        self.canvas.destroy()
        self.on_exit()

    def loop(self):
        if not self.is_running: return
        self.update_physics()
        self.draw()
        self.root.after(33, self.loop)

# ==========================================
# MENÚ PRINCIPAL
# ==========================================
class MainMenu:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("LABERINTO MASTER")
        self.root.geometry(f"{ANCHO_VENTANA}x{ALTO_VENTANA}")
        self.root.configure(bg="#111")
        self.crear_ui()

    def crear_ui(self):
        self.frame = tk.Frame(self.root, bg="#111")
        self.frame.place(relx=0.5, rely=0.5, anchor="center")
        
        tk.Label(self.frame, text="DUNGEON EXPLORER", font=("Impact", 40), bg="#111", fg="#fff").pack(pady=10)
        tk.Label(self.frame, text="Professional Edition", font=("Arial", 14), bg="#111", fg="#0088ff").pack(pady=5)
        
        btn_opts = {"font": ("Verdana", 12), "width": 25, "bg": "#333", "fg": "white", "relief": "flat", "pady": 10}
        
        tk.Button(self.frame, text="🟢 MODO AVENTURA", command=lambda: self.start("solo"), **btn_opts).pack(pady=5)
        tk.Button(self.frame, text="🔴 MODO JEFE", command=lambda: self.start("jefe"), **btn_opts).pack(pady=5)
        tk.Button(self.frame, text="🟣 MODO CARRERA", command=lambda: self.start("carrera"), **btn_opts).pack(pady=5)

        exit_opts = btn_opts.copy()
        exit_opts["bg"] = "#550000"
        tk.Button(self.frame, text="❌ SALIR DEL JUEGO", command=self.root.destroy, **exit_opts).pack(pady=20)

    def start(self, mode):
        self.frame.destroy()
        self.game = GameEngine(self.root, mode, self.reset)

    def reset(self):
        self.root.unbind("<KeyPress>")
        self.root.unbind("<KeyRelease>")
        self.crear_ui()

# ==========================================
# EJECUCIÓN PRINCIPAL
# ==========================================
if __name__ == "__main__":
    app = MainMenu()
    app.root.mainloop()


